#include <ctime>
#include <cstdlib>
int square(){
	srand(time(0));
	int x = rand()% 100+1;
	return x;
}
