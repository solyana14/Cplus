#include <iostream>
#include "Num.h"
using namespace std;
int main()
{
int x = square();
cout << x<<  " is a randoom number generated in header file"<< endl;
return 0;
}
